#import <Foundation/Foundation.h>
@interface XYPoint: NSObject

@property int x, y;

-(void) setX: (int) xVar andY: (int) yVar;

@end
