#import "XYPoint.h"

@implementation XYPoint

@synthesize x, y;

-(void) setX: (int) xVar andY: (int) yVar
{
	x = xVar;
	y = yVar;
}

@end
